const produtos = [
    {
        id: 1,
        nome: "SUPER BLASTER PC 9000",
        categoria: "pc",
        tag: "PODER MÁXIMO",
        icone: "🖥️",
        descricaoIcone: "Ícone de um computador de mesa com tela",
        caracteristicas: "Processador de última geração, Ray Tracing ligado e refrigeração líquida com brilho neon.",
        preco: 7990.00
    },
    {
        id: 2,
        nome: "ESTAÇÃO PORTÁTIL RETRO",
        categoria: "dispositivo",
        tag: "NOSTALGIA",
        icone: "🕹️",
        descricaoIcone: "Ícone de um joystick do tipo arcade",
        caracteristicas: "Visual clássico de console de sala. Carrega jogos num piscar de olhos com SSD ultra-rápido.",
        preco: 3590.00
    },
    {
        id: 3,
        nome: "FIGHTING HEROES 1999",
        categoria: "jogo",
        tag: "MÍDIA FÍSICA",
        icone: "💾",
        descricaoIcone: "Ícone de um disquete de computador",
        caracteristicas: "RPG de ação com combates explosivos, robôs gigantes e trilha sonora em synthwave puríssimo.",
        preco: 189.90
    },
    {
        id: 4,
        nome: "CYBER-BOOK TURBO",
        categoria: "pc",
        tag: "PORTÁTIL",
        icone: "💻",
        descricaoIcone: "Ícone de um computador portátil notebook",
        caracteristicas: "A tela mais nítida da galáxia para você jogar até na lanchonete às 3 horas da manhã.",
        preco: 4100.00
    },
    {
        id: 5,
        nome: "HEADSET NEON SOUND",
        categoria: "dispositivo",
        tag: "ÁUDIO 3D",
        icone: "🎧",
        descricaoIcone: "Ícone de fones de ouvido grandes",
        caracteristicas: "Som surround brutal. Ouça até os passos mais sutis dos inimigos no modo batalha.",
        preco: 399.00
    },
    {
        id: 6,
        nome: "MECHA CHRONICLES",
        categoria: "jogo",
        tag: "ED. LIMITADA",
        icone: "🎮",
        descricaoIcone: "Ícone de um controle de videogame",
        caracteristicas: "Edição especial com manual colorido, encarte de colecionador e pôster exclusivo em pixels.",
        preco: 220.00
    }
];

let carrinhoCount = 0;

// Renderizar Produtos de forma acessível
function renderizarProdutos(lista) {
    const grid = document.getElementById("products-grid");
    grid.innerHTML = "";

    lista.forEach(produto => {
        const artigo = document.createElement("article");
        artigo.className = "card";

        artigo.innerHTML = `
            <div class="card-pixel-display">
                <span class="card-tag">${produto.tag}</span>
                <span class="pixel-icon" role="img" aria-label="${produto.descricaoIcone}">${produto.icone}</span>
            </div>
            <div class="card-info">
                <h3 class="card-title">${produto.nome}</h3>
                <p class="card-specs">${produto.caracteristicas}</p>
                <div class="card-price" aria-label="Preço: R$ ${produto.preco.toFixed(2).replace('.', ',')}">
                    R$ ${produto.preco.toLocaleString('pt-BR', {minimumFractionDigits: 2})}
                </div>
                <button class="btn-buy" aria-label="Adicionar ${produto.nome} ao carrinho" onclick="adicionarAoCarrinho('${produto.nome}')">
                    ADICIONAR AO CARRINHO
                </button>
            </div>
        `;
        grid.appendChild(artigo);
    });
}

// Filtro de Categorias com atualização de acessibilidade
function filtrarProdutos(categoria, elementoBotao) {
    const botoes = document.querySelectorAll('.btn-category');
    botoes.forEach(btn => {
        btn.classList.remove('active');
        btn.setAttribute('aria-pressed', 'false');
    });
    
    if (elementoBotao) {
        elementoBotao.classList.add('active');
        elementoBotao.setAttribute('aria-pressed', 'true');
    }

    let filtrados = produtos;
    if (categoria !== 'todos') {
        filtrados = produtos.filter(prod => prod.categoria === categoria);
    }
    
    renderizarProdutos(filtrados);
    
    // Anuncia a filtragem para leitores de tela sem interromper a navegação
    atualizarLiveRegion(`Filtrado por ${categoria}. ${filtrados.length} produtos exibidos.`);
}

// Adicionar ao Carrinho com feedback sonoro acessível
function adicionarAoCarrinho(nomeItem) {
    carrinhoCount++;
    const cartCountEl = document.getElementById("cart-count");
    const cartButton = document.getElementById("cart-button");

    cartCountEl.innerText = carrinhoCount;
    cartButton.setAttribute("aria-label", `Mochila de compras, ${carrinhoCount} itens adicionados`);

    // Atualização em áudio para leitores de tela
    atualizarLiveRegion(`O item ${nomeItem} foi adicionado à sua mochila. Total de itens: ${carrinhoCount}`);
}

// Notificador dinâmico
function atualizarLiveRegion(mensagem) {
    const liveRegion = document.getElementById("status-live");
    liveRegion.innerText = mensagem;
}

// Inicialização
window.onload = () => {
    renderizarProdutos(produtos);
};